<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\User; 
use Illuminate\Support\Facades\Auth; 
use Validator;
use Hash;
class UserController extends Controller 
{
public $successStatus = 200;
/** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function login(Request $request){ 
        $validator = Validator::make($request->all(), [ 
            
            'email' => 'required|email', 
            'password' => 'required', 
           
        ]);
if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('MyApp')-> accessToken; 
            return response()->json(['success' => $success], $this-> successStatus); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }
/** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function register(Request $request) 
    { 
        $validator = Validator::make($request->all(), [ 
            'name' => 'required', 
            'email' => 'required|email', 
            'password' => 'required', 
            'c_password' => 'required|same:password', 
        ]);
if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
$input = $request->all(); 
        $input['password'] = bcrypt($input['password']); 
        $user = User::create($input); 
        $success['token'] =  $user->createToken('MyApp')-> accessToken; 
        $success['name'] =  $user->name;
return response()->json(['success'=>$success], $this-> successStatus); 
    }
/** 
     * details api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function details() 
    { 
        $user = Auth::user(); 
        return response()->json(['success' => $user], $this-> successStatus); 
    } 
    public function change_password(Request $request)
{
    $input = $request->all();
    $userid = Auth::guard('api')->user()->id;
    $rules = array(
        'old_password' => 'required',
        'new_password' => 'required|min:6',
        'confirm_password' => 'required|same:new_password',
    );
    $validator = Validator::make($input, $rules);
    if ($validator->fails()) {
      
      
        return response()->json(['error'=>$validator->errors()], 401); 
       
    } else {
        try {
            if ((Hash::check(request('old_password'), Auth::user()->password)) == false) {
                // $arr = array("status" => 400, "message" => "Check your old password.", "data" => array());
                $arr['status'] = 400;
                $arr['message'] = "Check your old password.";
                $status ='error';
            } else if ((Hash::check(request('new_password'), Auth::user()->password)) == true) {
                 $arr['status'] = 400;
                $arr['message'] = "Please enter a password which is not similar then current password.";
                $status ='error';
            } else {
              $user =  User::where('id', $userid)->update(['password' => Hash::make($input['new_password'])]);
             
              
                $arr['status'] = 200;
                $arr['message'] = "Password updated successfully.";
                $status ='success';
                if (Auth::check()) {
                    Auth::user()->AauthAcessToken()->delete();
                 }

            }
        } catch (\Exception $ex) {
            if (isset($ex->errorInfo[2])) {
                $msg = $ex->errorInfo[2];
            } else {
                $msg = $ex->getMessage();
            }
            $arr = array("status" => 400, "message" => $msg, "data" => $user->tokens);
            $arr['status'] = 400;
                $arr['message'] = $msg;
                
        }
    }
   
    return response()->json([$status => $arr]); 
}
}